const app = angular.module("main", []);
app.controller("myCtr", function ($scope) {
  $scope.me = "gmapdev";
});
