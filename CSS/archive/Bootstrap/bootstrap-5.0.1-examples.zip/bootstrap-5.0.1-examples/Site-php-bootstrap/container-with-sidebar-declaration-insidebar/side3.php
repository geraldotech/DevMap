<div class="container">
<div class="row align-items-start">
<div class="col-md-3 bg-light p-3 border ms-md-auto">
<h5 style="text-align:center;color:black">My Side bar 3 IMG with links</h5>
<div align="center">
<a href="http://cdn.gpnote.tech/files/chalk-artes-rj-logo-2020.jpg"> <img src="http://cdn.gpnote.tech/files/chalk-artes-rj-logo-2020.jpg" target="_blank" title="open new tab" width="250" height="250" /></a>
<br>
<a href="http://blog.com"target="_blank"> <img src="https://technotesbr.files.wordpress.com/2018/01/images.png" 
target="blank" width="200" height="250" alt="ChalkArtes logo" /></a>
</div>
</div>
</div>
</div>
