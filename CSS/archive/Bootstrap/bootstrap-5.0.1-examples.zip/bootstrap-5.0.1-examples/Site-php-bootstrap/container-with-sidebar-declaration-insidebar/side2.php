<div class="col-md-3 bg-light p-3 border ms-md-auto">
<div class="row justify-content-around">
<br>
<br>
<h5 style="background-color:purple;text-align:center">My Side bar 2 menu</h5>
<form style="text-align:center;">
<select onchange="top.location.href=this.form.links.options [this.form.links.selectedIndex].value" name="links">
<option selected/>Selecione um servidor
<option value="http://link1"/>Link Um
<option value="http://link2"/>Link Dois
<option value="http://link2"/>Link Dois
<option value="http://link2"/>Link Dois
<option value="http://link2"/>Link Dois
</select>
</form>
</div>
</div>
