<h5 style="background-color:green;text-align:center">My Side bar </h5>
col-md-3 B Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. <br>
<a href="#">LINK 1 </a> <br>
<a href="#">LINK 2 </a>  <br>
<a href="#">LINK 3 </a>  <br>
<div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
        <p class="card-text">It's a broader card with text below as a natural lead-in to extra content. This content is a little longer.</p>
        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
      </div>
    </div>
	<img src="http://img.gpnote.tech/2011/photoshopcs2.jpg" class="img-thumbnail" >
</div>
