# Fronteditor

https://fronteditor.dev

https://user-images.githubusercontent.com/6643122/159747376-b617c043-c5c3-4d41-8e51-33b18733a481.mp4

Online code editor for frontend, with possibility to use HTML, CSS, JavaScript and Markdown.

For study purposes. This tool will automatic save your work in your Browser's local storage.

## Features

- HTML, CSS, JavaScript editor
- Auto update as you coding
- Auto save as you coding
- You can use pathname `/anything` to start new empty project

> [Version 1](https://github.com/maykbrito/fronteditor) without React, TS nor monaco editor.
