# Todo-List
A simple Todo List App made using HTML, CSS, and Javascript. You can follow the tutorial here on my blog --> https://thecodingpie.com/post/how-to-build-a-todo-list-app-with-javascript-and-local-storage/
