//1
var age = 30;
var ano = 2022;
var res = ano - age;
document.getElementById("idade").innerHTML = res;
//shorthand
let [y,idade] = [2022,29];
console.log(y - idade);
//

//2
function bnt() {
    alert("boa noite");
}

//3 bntx
document.getElementById("bntx").onclick = function () {
    alert("boa noite");
}
//4 contador
var cont = "";
for(i=1;i<=10;i++) {
    cont += i;
}
document.getElementById("contador").innerHTML = cont;

//5  tabua
var c = "";
var opt = 7;
for(a=1; a<=10; a++) {
    c += opt +' x '+a + '='+opt*a+'<br>';
}
document.getElementById("tabua").innerHTML = c;

//6 hora
const d = new Date();
document.getElementById("hora").innerHTML = d;

//8
function txt2() {
    document.getElementById("txt").innerHTML = "Boa noite";
}

//8.2
function img2() {
    document.getElementById("img").innerHTML = '<img src="https://img.freepik.com/fotos-gratis/imagem-aproximada-em-tons-de-cinza-de-uma-aguia-careca-americana-em-um-fundo-escuro_181624-31795.jpg" />';
}

//9
document.getElementById("options").onchange = function () {
    var i = 1;
    var myDiv = document.getElementById(i);
    while (myDiv) {
        myDiv.style.display = 'none';
        myDiv = document.getElementById(++i);
    }
    document.getElementById(this.value).style.display = 'block';
}
//10
function texto2 () {
    var x = document.getElementById("texto");
    if (x.innerHTML == "Hello") {
        x.innerHTML = "Ola";
    } else {
        x.innerHTML = "Hello";
    }
}

//11 arrays
network = ['NETFLEX ','<p style="background:DodgerBlue;display:inline">Live TIM</p>','<p style="background:red;display:inline"> CLARO</p>'];
document.getElementById("array").innerHTML = network;

//12
function multiplica() {
    var num = (document.getElementById("num").value);
    var saida = document.getElementById("saida");
    var mu = "";
    for(i=1;i<=10;i++)
    mu += num+' x '+i+' = '+num*i+'<br>';
    saida.innerHTML = mu;
}

//13
function imgbnt() {
    var ximg = document.getElementById("imgx");
        if (ximg.style.display === "none") {
            ximg.style.display = 'block';
        } else {
            ximg.style.display = 'none';
        }
        }


//14 console.log
//const n = prompt("Digite um valor:");
if (n %2 === 0) {
    console.log('EVEN - PAR');
} else {
    console.log('ODD - IMPAR');
}

//14.2 operador ternário:
//const nn = prompt("Inserir numero:");
//*nn %2 == 0 ? console.log(+nn+" PAR") : console.log(+nn+" IMPAR");

//15)
let xj = document.getElementById('filho');
if(xj.className === "geraldo"){
    xj.textContent = "Petronilo";
} else {
    xj.className = "NaN Geraldo";
}

//16
function btn(){
    //e.preventDefault()
    n1 = document.getElementById("n1").value;
    max = document.getElementById("max").value;
    //caso o fosse apenas um numero, checkout se esta vazio
  /*   if(n1 === ''){
      return false;
    } */
    myres = document.getElementById("myres");
    res = '';
  for(i = 1; i<=max; i++){
    res += n1+' x '+i+'='+i*n1+'<br>';
  }
  myres.innerHTML = res;
  }
