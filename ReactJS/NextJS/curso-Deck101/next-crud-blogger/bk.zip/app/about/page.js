export default function Page() {
  return (
    <h1>
      Hello from <code>/about/page.js</code>
      <a href="https://nextjs.org/docs/app/api-reference/file-conventions/page">
        https://nextjs.org/docs/app/api-reference/file-conventions/page
      </a>
    </h1>
  )
}
