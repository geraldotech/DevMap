- create a `loading.js` tailwind CSS [https://flowbite.com/docs/components/skeleton/](https://flowbite.com/docs/components/skeleton/)
- Products [https://flowbite.com/docs/components/tables/](https://flowbite.com/docs/components/tables/)
- criar esqueleto de carregamento, baseado no React Suspense
- esqueleto que fica pulsando o carregamento
- melhorar a experiência do usuário
- React Suspense basicamente tem 2 proproedades
  children: o que está dentro do component de suspense
  fallback: esqueleto

<br>
- [Video](https://www.youtube.com/watch?v=K2Eyf7YOx-o)
