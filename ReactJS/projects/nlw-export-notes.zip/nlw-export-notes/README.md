## Links

- [https://tailwindcss.com/docs/guides/vite](https://tailwindcss.com/docs/guides/vite)
- Radix Components e suas funcionalidades sem CSS, tras acessibilidade pelo taclado [tabidnex] muito recomendado[https://www.radix-ui.com/primitives/docs/components/dialog](https://www.radix-ui.com/primitives/docs/components/dialog)

- Excelente Lib para Datas, existe outro como Dayjs

  - `npm i date-fns`

- sonner - Lib para toast https://sonner.emilkowal.ski/

  - `npm install sonner`
  - `import { Toaster } from 'sonner'` and wrapper the root main or app
  - in functions: ` toast.success('Nota criada com sucesso!')`
  - dica: ` <Toaster richColors />` para better colors

- Icons usando:
  - `npm i lucide-react`
