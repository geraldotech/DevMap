import React from "react"

export default function GrandChild() {
    console.log("[ ]   [ ]   [ ]   [👶🏻] rendered")
    return (
        <div className="grandchild">
            <p>GrandChild Component</p>
        </div>
    )
}
