# React + Vite

## MPA vs SPA

## MirageJS Server

instalei como `npm i miragejs` sem -D dev - foi instalado como dependencia de production
Efetuado o deploy do build no netlify em https://react-miragejs-server.netlify.app/ e works nice!

### useEffect()

fez uma const que recebera o div com map e depois call this const no return

# React Router Advanced

## Route Params

Create a <Link> to `/vans/:id` and Create a `VansDetails.jsx` and
Using <Link> in map wrapper the content of card

check Van.jsx

#### Multi params

Check App.jsx
<Route path="path="/vans/:id/:type"element={<VanDetail} /> == http://localhost:5173/vans/1/gera returns a `{id: '1', type: 'gera'}`

## useParams()

check VanDetails.jsx

const params = useParams() - params.id or destructuring
const { id } = useParams()

## Nested Routers
