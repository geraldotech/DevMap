import './App.css'
import './server'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Vans from './pages/vans'
import VanDetail from './pages/vanDetails'
import Layout from './components/Layout'

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route
              path="/"
              element={<Home />}
            />
            <Route
              path="/vans"
              element={<Vans />}
            />
            <Route
              path="/about"
              element={<About />}
            />
            {/* Route Params */}
            <Route
              path="/vans/:id"
              element={<VanDetail />}
            />
          </Route>

          {/*deixar a route fora do parent <Route> quando desejar que essa rota nao carregue o layout <Route
            path="/about"
            element={<About />}
          /> */}
        </Routes>
      </BrowserRouter>
    </>
  )
}
