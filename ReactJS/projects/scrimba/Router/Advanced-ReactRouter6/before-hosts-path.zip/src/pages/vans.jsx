import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'

export default function vans() {
  const [vans, setVans] = React.useState([])

  useEffect(() => {
    fetch('/api/vans')
      .then((req) => req.json())
      .then((data) => setVans(data.vans))
  }, [])

  const vanElements = vans.map((van) => (
    <div
      key={van.id}
      className="van-title">
      <Link to={`/vans/${van.id}`}>
        <img src={van.imageUrl} />
        <div className="van-info">
          <h2>{van.name}</h2>
          <p>
            ${van.price} <span>/days</span>
          </p>
        </div>
        <i className={`van-type ${van.type} selected`}>{van.type}</i>
      </Link>
    </div>
  ))

  return (
    <div className="van-list-container">
      <h1>Explorer our van options</h1>
      <div className="van-list">{vanElements}</div>
    </div>
  )
}
