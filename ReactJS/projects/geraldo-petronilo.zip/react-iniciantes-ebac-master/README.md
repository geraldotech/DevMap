# Como iniciar nosso projeto

1. Rode o comando `npm install` para podermos instalarmos todas as nossas dependencias.
2. Rode o comando `npm run start` para podemor subirmos nossa aplicação
3. Prontinho nosso sistema que checa a previsão do tempo esta rodando!!



## Desafio!!

- [ ] Criar loading para informamos ao usuário que estamos buscando sua previsão do tempo
- [ ] Mostrar para o usuário cidade e estado da previsão que ele esta vendo
- [ ] Mostrar informações adicionar como por exemplo: velocidade do vendo, visibilidade, humidade e etc!! Sinta-se livre para mostrar as informações que você quiser.
- [ ] Limpar o campo de busca após clicar no botão buscar.
- [ ] Informar para o usuário quando ocorreu algum erro na requisição ou não foi encontrada a cidade.
- [ ] Ser bastante criativo, não se limite, se quiser implementar alguma nova função fique a vontade!! 