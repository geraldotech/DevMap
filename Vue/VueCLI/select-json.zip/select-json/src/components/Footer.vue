<template>
  <div>
    <footer>
      <h3>{{ foo }}</h3>
    </footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      foo: "footer",
    };
  },
};
</script>

<style>
</style>