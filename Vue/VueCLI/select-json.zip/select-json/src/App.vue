<template>
  <div>
    <h2>Hello World</h2>
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </nav>
    <SelectJson />
    <router-view />

    <Foo />
  </div>
</template>
<script>
import SelectJson from "./components/SelectJson.vue";
import Foo from "./components/Footer.vue";
export default {
  name: "App",
  components: {
    SelectJson,
    Foo,
  },
  data() {
    return {};
  },
};
</script>
<style>
* {
  color-scheme: dark;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
