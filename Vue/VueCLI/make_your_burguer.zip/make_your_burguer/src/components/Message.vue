<template>
  <div class="message-container">
    <p>{{ msg }}</p>
  </div>
</template>
<script>
export default {
  name: "Message",
  props: {
    msg: String,
  },
  destroyed() {
    this.$emit("limpar");
  },
  beforeMounted() {
    console.log("mudou");
  },
};
</script>
<style scoped>
.message-container {
  color: #004085;
  background-color: #cce5ff;
  border: 2px solid #b8daff;
  border-radius: 5px;
  padding: 10px;
  max-width: 400px;
  margin: 30px auto;
  text-align: center;
}
</style>