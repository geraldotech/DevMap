<template>
  <div>
    <p>Hello Tester</p>
  </div>
</template>

<script>
module.exports = {};
</script>

<style>
</style>