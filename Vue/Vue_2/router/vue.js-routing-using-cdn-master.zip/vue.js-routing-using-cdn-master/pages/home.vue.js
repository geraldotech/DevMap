var Home = {
  template: `<div><h1>Home</h1><p>This is home page</p>
	<a href="https://shouts.dev/articles/vue-js-routing-from-scratch-using-cdn-without-cli">REF</a>
	</div>`,
};
