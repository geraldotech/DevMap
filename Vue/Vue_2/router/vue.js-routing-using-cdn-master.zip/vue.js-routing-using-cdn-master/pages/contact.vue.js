var Contact = { 
	template: "<div><h1>Contact</h1><p>This is contact page</p></div>"
};