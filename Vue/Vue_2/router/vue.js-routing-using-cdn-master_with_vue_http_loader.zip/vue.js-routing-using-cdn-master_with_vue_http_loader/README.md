## Vue.js Routing Using CDN
Today I am going to share how to route in Vue.js using CDN only. We won’t use CLI, Webpack, etc. We are going to see the very simple routing. For the big project, we have to use Vue Router using CLI.

## Tutorial Link
[Vue.js Routing From Scratch Using CDN Without CLI](https://www.mynotepaper.com/vue-js-routing-from-scratch-using-cdn-without-cli.html)

## Output
![vuejs-router-with-cdn-output](https://user-images.githubusercontent.com/13184472/57390177-897ea400-71dd-11e9-89a2-6e312335998c.gif)


## LICENCE

You can download the project, modify the code and use it anywhere you want without re-posting to your blog. Happy Coding :)

Thank you.
