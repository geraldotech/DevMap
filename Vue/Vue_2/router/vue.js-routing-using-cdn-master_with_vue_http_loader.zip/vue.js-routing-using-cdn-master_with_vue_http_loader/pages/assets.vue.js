var Assets = {
  template: `../img`,
};
