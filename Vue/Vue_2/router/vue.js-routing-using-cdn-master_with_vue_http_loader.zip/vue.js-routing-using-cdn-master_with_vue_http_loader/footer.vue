<template>
  <footer>
    <p>exemplo de rotas com http-vue-loader</p>
    <p>footer</p>
  </footer>
</template>

<style scoped>
footer {
  background: rgb(63, 39, 31);
  height: 50px;
  text-align: center;
}
</style>>
