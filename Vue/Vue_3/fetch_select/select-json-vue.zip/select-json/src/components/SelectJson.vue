<template>
  <div>
    <h1>e.g v-for select from JSON, and :selected value v-model</h1>
    <select name="" id="" v-model="opt">
      <option value="">Selecionar:</option>
      <option
        v-for="card in cards"
        :key="card.id"
        :value="card.limite"
        :selected="opt"
      >
        <!-- 
        bind selected para opt, e v-model com opt que recebe o value
      -->
        {{ card.tipo }}
      </option>
    </select>
    <p>{{ opt }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      cards: null,
      opt: "",
    };
  },

  methods: {
    async bancos() {
      const req = await fetch("http://localhost:3000/cartoes");
      const data = await req.json();

      this.cards = data.cards;
      this.cardLimit = data.cards.limite;
    },
  },
  mounted() {
    this.bancos();
  },
};
</script>