<template>
  <div class="container mt-10">
    <SelectJson />
  </div>
</template>


<script>
import SelectJson from "./components/SelectJson.vue";

export default {
  name: "App",
  components: {
    SelectJson,
  },
  data() {
    return {
      gp: "Geraldo - não pode faltar o return in `data`",
    };
  },
};
</script>
<style scoped>
p {
  color: rebeccapurple;
}
</style>
