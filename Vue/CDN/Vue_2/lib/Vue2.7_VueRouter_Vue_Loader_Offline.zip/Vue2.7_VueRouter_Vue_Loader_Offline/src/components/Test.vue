<template>
  <div>
    <p>Hello Test.vue</p>
  </div>
</template>

<script>
module.exports = {};
</script>

<style>
</style>