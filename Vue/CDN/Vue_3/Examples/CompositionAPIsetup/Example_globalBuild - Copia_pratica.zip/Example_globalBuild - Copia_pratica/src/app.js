const { createApp, ref, reactive, computed, watch, onMounted } = Vue

const app = Vue.createApp({
  setup() {
    const itens = ['Home', 'Sobre', 'Contato']
    const ativoIndex = ref(0) // índice do item ativo
    const divRef = ref(null)
    const divP = ref(null)

    const re = ref({
      age: 30,
      name: 'Geraldo'
    })




    function selecionar(index) {
      ativoIndex.value = index
    }
    

    onMounted(() => {
      // (Opcional) Acessar a div assim que o componente montar
      console.log('Altura da div:', divRef.value?.clientHeight)
      console.log(divRef.value)
      console.log(divP.value)

    })

    return {
      handlerClick: () => {
        console.log(`ok`)
      }, itens, ativoIndex, selecionar, divRef, divP, re
      
    }
  },
  data() {
    return {
      foo: 'Vue !',
    }
  },
}).mount('#app')

// https://vuejs.org/guide/quick-start.html#splitting-up-the-modules
