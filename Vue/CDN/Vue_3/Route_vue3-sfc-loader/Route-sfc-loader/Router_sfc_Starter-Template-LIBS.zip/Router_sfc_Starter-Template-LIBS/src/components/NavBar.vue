<template>
  <div id="rotas">
    <nav>
      <ul>
        <router-link to="/">Home</router-link>
        <router-link to="/route1">About</router-link>
        <router-link to="/route2">Port</router-link>
        <router-link to="/route3">Radio</router-link>
      </ul>
    </nav>
  </div>
</template>
<script>
</script>