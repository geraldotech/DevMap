<template>
  <div>
    <h4>Extra Vue</h4>
  </div>
</template>

<script>
module.exports = {
  data: function () {
    return {
      who: "world",
      gp: "Geraldo",
    };
  },
};
</script>
<style>
/*global */
.hello {
  background-color: rgb(31, 31, 13);
  color: white;
}

h4 {
  color: orange;
}
</style>