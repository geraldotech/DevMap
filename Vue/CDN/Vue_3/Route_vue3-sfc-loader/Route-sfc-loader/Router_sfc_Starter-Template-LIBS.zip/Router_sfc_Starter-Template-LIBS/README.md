- Router load .vue
- Router load string templates
- Type-module for better coding
- App as parent of subcomponentes melhor controle dos componentes baseado no Vue CLI
- myHeader is set CSS Global mode
- NavBar has router-links e no App.vue tem o router-view
- type-module pq vai precisar importar o rotas.js
- em inves de chamar o component `<MyHeader></MyHeader>` just call `<MyHeader />`

## Erros:

Fixied error:
"defineAsyncComponent()". Write "() => import('

https://stackoverflow.com/questions/67044999/how-to-use-createasynccomponent-in-vuerouter4-0-0-vue3
