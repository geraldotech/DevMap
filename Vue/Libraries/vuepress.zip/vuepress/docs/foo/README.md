# Foo page

- [Home](/)
  - [one](/foo/one/)
  - [two](/foo/two/)

  